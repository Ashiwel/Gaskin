// Gaskin local server (Node 18 or newer, no packages). Serves this folder on 127.0.0.1 only.
// Usage: node serve.js <folder> [--no-open]
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');
const ROOT = path.resolve(process.argv[2] || path.join(__dirname, '..'));
const ROUTES = {"/":"Gaskin.html","/index.html":"Gaskin.html","/Gaskin.html":"Gaskin.html","/sw.js":"app/sw.js","/manifest.webmanifest":"app/manifest.webmanifest","/icon.svg":"app/icon.svg","/icon-maskable.svg":"app/icon-maskable.svg","/favicon.svg":"app/favicon.svg","/gaskin.mcpb":"gaskin.mcpb"};
const MIME = {".html":"text/html; charset=utf-8",".js":"text/javascript; charset=utf-8",".json":"application/json",".webmanifest":"application/manifest+json",".svg":"image/svg+xml",".png":"image/png",".txt":"text/plain; charset=utf-8"};
const server = http.createServer((req, res) => {
  if (req.method !== 'GET' && req.method !== 'HEAD') return res.writeHead(405).end();
  const rel = ROUTES[(req.url || '/').split('?')[0].split('#')[0]];
  if (!rel) return res.writeHead(404).end('Not found');
  fs.readFile(path.join(ROOT, rel), (err, body) => {
    if (err) return res.writeHead(404).end('Not found');
    const ext = path.extname(rel);
    const h = { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Content-Length': body.length, 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer', 'Cross-Origin-Opener-Policy': 'same-origin' };
    if (ext === '.html') h['X-Frame-Options'] = 'DENY';
    res.writeHead(200, h);
    res.end(req.method === 'HEAD' ? undefined : body);
  });
});
const ports = [17654, 17655, 17656, 17657, 0];
const listen = (i) => {
  server.once('error', () => listen(i + 1));
  server.listen(ports[i], '127.0.0.1', () => {
    const url = 'http://127.0.0.1:' + server.address().port + '/';
    console.log('Gaskin is running at ' + url);
    console.log('Keep this window open while you use Gaskin. Close it to stop.');
    if (process.argv.includes('--no-open')) return;
    const cmd = process.platform === 'win32' ? ['cmd', ['/c', 'start', '', url]] : process.platform === 'darwin' ? ['open', [url]] : ['xdg-open', [url]];
    try { spawn(cmd[0], cmd[1], { stdio: 'ignore', detached: true }).unref(); } catch {}
  });
};
listen(0);
