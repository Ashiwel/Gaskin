# Gaskin local server (Python 3, standard library only). Serves this folder on 127.0.0.1 only.
# Usage: python3 serve.py <folder> [--no-open]
import http.server, json, os, socket, sys, threading, webbrowser

ROOT = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), '..'))
ROUTES = {"/":"Gaskin.html","/index.html":"Gaskin.html","/Gaskin.html":"Gaskin.html","/sw.js":"app/sw.js","/manifest.webmanifest":"app/manifest.webmanifest","/icon.svg":"app/icon.svg","/icon-maskable.svg":"app/icon-maskable.svg","/favicon.svg":"app/favicon.svg","/gaskin.mcpb":"gaskin.mcpb"}
MIME = {".html":"text/html; charset=utf-8",".js":"text/javascript; charset=utf-8",".json":"application/json",".webmanifest":"application/manifest+json",".svg":"image/svg+xml",".png":"image/png",".txt":"text/plain; charset=utf-8"}

class Handler(http.server.BaseHTTPRequestHandler):
    server_version = 'Gaskin'
    sys_version = ''
    def do_HEAD(self):
        self.send(head=True)
    def do_GET(self):
        self.send(head=False)
    def send(self, head):
        path = self.path.split('?', 1)[0].split('#', 1)[0]
        rel = ROUTES.get(path)
        if rel is None:
            self.send_error(404, 'Not found')
            return
        full = os.path.join(ROOT, rel)
        try:
            with open(full, 'rb') as f:
                body = f.read()
        except OSError:
            self.send_error(404, 'Not found')
            return
        ext = os.path.splitext(full)[1]
        self.send_response(200)
        self.send_header('Content-Type', MIME.get(ext, 'application/octet-stream'))
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-cache')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Cross-Origin-Opener-Policy', 'same-origin')
        if ext == '.html':
            self.send_header('X-Frame-Options', 'DENY')
        self.end_headers()
        if not head:
            self.wfile.write(body)
    def log_message(self, *args):
        pass

def free_port():
    # Same port each time when it is free, so the browser keeps the same records and app install.
    for port in [17654, 17655, 17656, 17657, 0]:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            s.bind(('127.0.0.1', port))
            p = s.getsockname()[1]
            s.close()
            return p
        except OSError:
            s.close()
    raise SystemExit('No free port')

port = free_port()
httpd = http.server.ThreadingHTTPServer(('127.0.0.1', port), Handler)
url = 'http://127.0.0.1:%d/' % port
print('Gaskin is running at ' + url)
print('Keep this window open while you use Gaskin. Close it to stop.')
sys.stdout.flush()
if '--no-open' not in sys.argv:
    threading.Timer(0.5, lambda: webbrowser.open(url)).start()
try:
    httpd.serve_forever()
except KeyboardInterrupt:
    pass
