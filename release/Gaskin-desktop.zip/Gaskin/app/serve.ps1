# Gaskin local server for Windows PowerShell (no Python or Node needed). 127.0.0.1 only.
param([string]$Root = (Join-Path $PSScriptRoot '..'))
$Root = (Resolve-Path $Root).Path
$routes = @{ '/' = 'Gaskin.html'; '/index.html' = 'Gaskin.html'; '/Gaskin.html' = 'Gaskin.html'; '/sw.js' = 'app\sw.js'; '/manifest.webmanifest' = 'app\manifest.webmanifest'; '/icon.svg' = 'app\icon.svg'; '/icon-maskable.svg' = 'app\icon-maskable.svg'; '/favicon.svg' = 'app\favicon.svg'; '/gaskin.mcpb' = 'gaskin.mcpb' }
$mime = @{ '.html' = 'text/html; charset=utf-8'; '.js' = 'text/javascript; charset=utf-8'; '.json' = 'application/json'; '.webmanifest' = 'application/manifest+json'; '.svg' = 'image/svg+xml'; '.png' = 'image/png'; '.txt' = 'text/plain; charset=utf-8' }
$listener = $null
foreach ($port in 17654, 17655, 17656, 17657, 17658) {
  try {
    $l = New-Object System.Net.HttpListener
    $l.Prefixes.Add("http://127.0.0.1:$port/")
    $l.Start()
    $listener = $l
    break
  } catch { }
}
if (-not $listener) { Write-Host 'No free port.'; exit 1 }
$url = $listener.Prefixes | Select-Object -First 1
Write-Host "Gaskin is running at $url"
Write-Host 'Keep this window open while you use Gaskin. Close it to stop.'
Start-Process $url
while ($listener.IsListening) {
  $ctx = $listener.GetContext()
  $path = $ctx.Request.Url.AbsolutePath
  $res = $ctx.Response
  try {
    if ($routes.ContainsKey($path)) {
      $file = Join-Path $Root $routes[$path]
      $bytes = [System.IO.File]::ReadAllBytes($file)
      $ext = [System.IO.Path]::GetExtension($file)
      $res.ContentType = $(if ($mime.ContainsKey($ext)) { $mime[$ext] } else { 'application/octet-stream' })
      $res.Headers.Add('Cache-Control', 'no-cache')
      $res.Headers.Add('X-Content-Type-Options', 'nosniff')
      $res.ContentLength64 = $bytes.Length
      if ($ctx.Request.HttpMethod -ne 'HEAD') { $res.OutputStream.Write($bytes, 0, $bytes.Length) }
    } else { $res.StatusCode = 404 }
  } catch { $res.StatusCode = 404 }
  $res.Close()
}
