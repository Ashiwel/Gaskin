@echo off
rem Open Gaskin (Windows): serves this folder on http://127.0.0.1 and opens your browser.
rem Uses Python 3, else PowerShell, else Node. With none of them, opens Gaskin.html directly.
title Gaskin
cd /d "%~dp0"
set "HERE=%~dp0."

where py >nul 2>nul
if not errorlevel 1 (
  py -3 -c "import sys" >nul 2>nul
  if not errorlevel 1 goto python_launcher
)
where python >nul 2>nul
if not errorlevel 1 (
  python -c "import sys; sys.exit(0 if sys.version_info[0] == 3 else 1)" >nul 2>nul
  if not errorlevel 1 goto python_plain
)
where powershell >nul 2>nul
if not errorlevel 1 goto powershell
where node >nul 2>nul
if not errorlevel 1 goto node
echo Python, PowerShell and Node were not found, so Gaskin opens straight from the file.
start "" "%HERE%\Gaskin.html"
goto :eof

:python_launcher
py -3 "%HERE%\app\serve.py" "%HERE%"
goto :eof
:python_plain
python "%HERE%\app\serve.py" "%HERE%"
goto :eof
:powershell
powershell -NoProfile -ExecutionPolicy Bypass -File "%HERE%\app\serve.ps1" -Root "%HERE%"
goto :eof
:node
node "%HERE%\app\serve.js" "%HERE%"
goto :eof
