#!/bin/sh
# Open Gaskin (Mac): serves this folder on http://127.0.0.1 and opens your browser.
# Uses Python 3, else Node. With neither, opens Gaskin.html directly, which still works.
cd "$(dirname "$0")" || exit 1
HERE="$(pwd)"
if command -v python3 >/dev/null 2>&1 && python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3, 7) else 1)' 2>/dev/null; then
  exec python3 "$HERE/app/serve.py" "$HERE" "$@"
fi
if command -v node >/dev/null 2>&1; then
  exec node "$HERE/app/serve.js" "$HERE" "$@"
fi
echo "Python 3 and Node were not found, so Gaskin opens straight from the file."
echo "It works, but cannot install as an app or save into a folder of your choice."
open "$HERE/Gaskin.html"
